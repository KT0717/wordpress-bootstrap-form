-- Adminer 4.7.8 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `wp_test_form`;
CREATE TABLE `wp_test_form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `gender` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `email` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `address` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `members` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tel` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `level` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


-- 2021-04-17 06:57:50
